package hobby;

public class TradeMain {
    public static void main(String[] args) {
        TradeService tService = new TradeService();
        tService.start();
    }
}
